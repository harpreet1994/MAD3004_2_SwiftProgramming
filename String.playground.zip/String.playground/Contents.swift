//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var coordinates = (40, 20)

switch coordinates {
case(0,0):
    print("start of canvas")
case(100,100):
    print("end of canvas")
case(10, 20):
    print(" center of canvas")
case(10,_):
    print("x axis")
case(_, 20):
    print("y axis")
case(101...200 ,101...200):
    print("outside the canvas")
default:
    print("canvas unavailable")
    
}

var range = 1...100
print(range)
print(range.contains(45))
print(range.contains(453))
print("lower bound" , range.lowerBound)
print("upper bound" , range.upperBound)

for itr in 0..<5{
    print("itr : \(itr)")
}

var friends = ["simran" , " anu" , "aman", "prabhjeet" ]
var length = friends.count
for itr in 0..<length{
    print(" friends : \(friends [itr])")
}

for frnd in friends[1...]{
    print(" ====\(frnd)")
}
for frnd in friends[...2]{
    print("@@@\(frnd)")
    
}

for char in "good🙂"{
    print("character : \(char)")
}
var govinda = """
answer to yesterday's question
what could you have been instead of being teacher?
you know about the answer.
Response :: i dont know.
"""


govinda += " i would be an Astronaut"

govinda.append(" ohhh really !!!😎 \u{1f496}")
print(govinda)
var value = String()
value = "too much "

if value.isEmpty{
    print("value not available")
}else{
    print(value)
}

var day = "Saturday"
//saturday_
print("startIndex : \(day[day.startIndex])")
   // print("endIndex : \(day[day.endIndex])" )

print("last character : \(day[day.index(before: day.endIndex )])")

print("second character : \(day[day.index(after:day.startIndex)])")
print("4th character : \(day[day.index(day.startIndex,offsetBy:  3)])")

print("3rd from last : \(day[day.index(day.endIndex,offsetBy:-3)])")

var index = day.index(of: "t") ?? day.startIndex
print("char t : \(day[index])")

for idx in day.indices{
    print("\(day[idx])" , terminator : " _ ")
    
}
 print()

for  (idx,char) in day.enumerated(){
    print("Index : \(idx) Char : \(char)")
    
}
print(day.uppercased())
print(day.lowercased())

day.insert("!", at: day.endIndex)
print(day)

day.insert( contentsOf: " No class please", at: day.endIndex)
print(day)

var idx1 = day.index(of: "!") ?? day.endIndex
day.remove(at: idx1)
print(day)

idx1 = day.index(of: "N") ?? day.endIndex
var idx2 = day.index(of: "s") ?? day.endIndex
day.removeSubrange(idx1...idx2)
print(day)

//Saturday s please

day.removeAll()
print("day : " ,day)




